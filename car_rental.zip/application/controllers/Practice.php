<?php
class Practice extends CI_Controller{
	public function index()
	{
		$this->load->view('try');
	}
}
?>
