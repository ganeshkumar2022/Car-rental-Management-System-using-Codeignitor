<ul type="none">
    <li><a href="<?=base_url('home/profile')?>" class="text-decoration-none text-dark">Profile settings</a></li>
    <li><a href="<?=base_url('home/updatePassword')?>" class="text-decoration-none text-dark">Update Password</a></li>
    <li><a href="<?=base_url('home/mybookings')?>" class="text-decoration-none text-dark">My Booking</a></li>
    <li><a href="<?=base_url('home/postaTestimonial')?>" class="text-decoration-none text-dark">Post a Testimonial</a></li>
    <li><a href="<?=base_url('home/myTestimonial')?>" class="text-decoration-none text-dark">My Testimonial</a></li>
    <li><a href="<?=base_url('home/logout')?>" class="text-decoration-none text-dark">Logout</a></li>
</ul>